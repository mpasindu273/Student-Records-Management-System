package eaassignment;
import static eaassignment.login.account;
import java.awt.List;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class register extends javax.swing.JFrame {
    static String gender;
    static int id;
    
    private static final String REGISTER_SQL = "INSERT INTO Registration" + "  (firstName, lastName, dateOfBirth, gender, address, email, mobilePhone, homePhone, parentName, nic, contactNo) VALUES "
			+ " (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    private static final String UPDATE_SQL = "UPDATE Registration SET firstName=?, lastname=?, dateOfBirth=?, gender=?, address=?, email=?, mobilePhone=?, homePhone=?, parentName=?, nic=?, contactNo=? where regNo=?;";
    private static final String DELETE_SQL = "DELETE FROM Registration WHERE regNo = ?;";
    public register() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        regCombo = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tfirst = new javax.swing.JTextField();
        tlast = new javax.swing.JTextField();
        rbmale = new javax.swing.JRadioButton();
        rbfemale = new javax.swing.JRadioButton();
        DOBchooser = new com.toedter.calendar.JDateChooser();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        tmobile = new javax.swing.JTextField();
        temail = new javax.swing.JTextField();
        thome = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        taddress = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        tparent = new javax.swing.JTextField();
        tnic = new javax.swing.JTextField();
        tcontact = new javax.swing.JTextField();
        blogout = new javax.swing.JButton();
        bregister = new javax.swing.JButton();
        bupdt = new javax.swing.JButton();
        bclear = new javax.swing.JButton();
        bdelete = new javax.swing.JButton();
        bclear1 = new javax.swing.JButton();
        bedit = new javax.swing.JButton();
        bchangepw = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        jLabel1.setText("Skills International");

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel2.setText("Reg No");

        regCombo.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        regCombo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                regComboFocusGained(evt);
            }
        });
        regCombo.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                regComboPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                regComboPopupMenuWillBecomeVisible(evt);
            }
        });
        regCombo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                regComboMouseClicked(evt);
            }
        });
        regCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regComboActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("First Name");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Last Name");

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel14.setText("Date of Birth");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Gender");

        tfirst.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        tlast.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        buttonGroup1.add(rbmale);
        rbmale.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rbmale.setText("Male");
        rbmale.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbmaleMouseClicked(evt);
            }
        });
        rbmale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbmaleActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbfemale);
        rbfemale.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rbfemale.setText("Female");
        rbfemale.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbfemaleMouseClicked(evt);
            }
        });
        rbfemale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbfemaleActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(tfirst, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tlast, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                            .addComponent(rbmale)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(rbfemale))
                                        .addComponent(DOBchooser, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(32, 32, 32))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfirst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tlast, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(DOBchooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(rbmale)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(rbfemale)))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Address");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Email");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Mobile Phone");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("Home Phone");

        tmobile.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tmobile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tmobileKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tmobileKeyTyped(evt);
            }
        });

        temail.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        thome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        thome.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                thomeKeyPressed(evt);
            }
        });

        taddress.setColumns(20);
        taddress.setRows(5);
        jScrollPane1.setViewportView(taddress);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(tmobile, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel12)
                                .addGap(13, 13, 13)
                                .addComponent(thome, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(temail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(31, 31, 31))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel7))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(temail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel12)
                        .addComponent(tmobile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(thome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel4.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Parent Name");

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("NIC");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("Contact Number");

        tparent.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        tnic.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        tcontact.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tcontact.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tcontactKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel13)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tparent, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(tnic, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
                        .addComponent(tcontact, javax.swing.GroupLayout.Alignment.LEADING)))
                .addGap(31, 31, 31))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(tparent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(tnic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(tcontact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel2)
                        .addGap(103, 103, 103)
                        .addComponent(regCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        blogout.setText("Logout");
        blogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                blogoutActionPerformed(evt);
            }
        });

        bregister.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        bregister.setText("Register");
        bregister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bregisterActionPerformed(evt);
            }
        });

        bupdt.setText("Update");
        bupdt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bupdtActionPerformed(evt);
            }
        });

        bclear.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        bclear.setText("Clear");
        bclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bclearActionPerformed(evt);
            }
        });

        bdelete.setText("Delete");
        bdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bdeleteActionPerformed(evt);
            }
        });

        bclear1.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        bclear1.setText("View ");
        bclear1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bclear1ActionPerformed(evt);
            }
        });

        bedit.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        bedit.setText("Edit Admin");
        bedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beditActionPerformed(evt);
            }
        });

        bchangepw.setText("Change Password");
        bchangepw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bchangepwActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(blogout)
                        .addGap(18, 18, 18)
                        .addComponent(bchangepw)
                        .addGap(31, 31, 31)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bedit, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bclear1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bregister)
                            .addComponent(bupdt, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bdelete, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bclear, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(blogout, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(bchangepw, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(bedit, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(159, 159, 159)
                        .addComponent(bregister, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bupdt, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bdelete, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bclear, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(bclear1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void checkLength(javax.swing.JTextField txt){
      String str = txt.getText();
      if(str.length()>=9){
        JOptionPane.showMessageDialog(null,"Enter 9 numbers only!", "", JOptionPane.WARNING_MESSAGE);
        txt.setText(str.substring(0,9));
      }
    }
    
    
    private void eliminateDuplicates()
    {
        int stats=1;
        for(int i=0;i<regCombo.getItemCount();i++)
       {
        int cbitem=Integer.parseInt(regCombo.getItemAt(i));
        if(cbitem == id)
        {
          stats=0;
          break;
        }
       }//for
        
        if(stats==1)
        {
         regCombo.addItem(String.valueOf(id));
        }
     } 
    
    private void setGender(){
     if(rbmale.isSelected()){
        gender = "Male";
     }
                     
     else if(rbfemale.isSelected()){
        gender = "Female";
     } 
   }
    
      private void loadIndexes(){                          
        String sql= "SELECT regNo FROM Registration;";              
        try 
        {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
		PreparedStatement ps;
                ps=con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                  while (rs.next()) 
                  {      
                   id = rs.getInt("regNo");                   
                   eliminateDuplicates();                    
                  }
                con.close();
	} 
        catch (Exception e)
        {
	   e.printStackTrace();
	}       
    }   
    
    private void loadData(){
       String sql = "SELECT * FROM Registration WHERE regNo = ?;"; 
       String firstname,lastname, gender, address, email, mobile, home, parent, nic, contact;
       Date date;

       id = Integer.parseInt(regCombo.getSelectedItem().toString());
        try 
        {			
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
		PreparedStatement ps;           
                ps=con.prepareStatement(sql);
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                  while (rs.next()) 
                  {	                    
                     firstname = rs.getString("firstName");
                     lastname = rs.getString("lastName");
                     date = rs.getDate("dateOfBirth");                 
                     gender = rs.getString("gender");
                     address = rs.getString("address");
                     email = rs.getString("email");
                     mobile = String.valueOf(rs.getInt("mobilePhone"));
                     home = String.valueOf(rs.getInt("homePhone"));
                     parent = rs.getString("parentName");
                     nic = rs.getString("nic");
                     contact = String.valueOf(rs.getInt("contactNo"));   
                     
                     tfirst.setText(firstname);
                     tlast.setText(lastname);
                     DOBchooser.setDate(date);  
                     taddress.setText(address);
                     temail.setText(email);
                     tmobile.setText(mobile);
                     thome.setText(home);
                     tparent.setText(parent);
                     tnic.setText(nic);
                     tcontact.setText(contact);
                     
                     if(gender.equals("Male")){
                       rbmale.setSelected(true);
                       gender="male";
                     }
                     
                     else if(gender.equals("Female")){
                       rbfemale.setSelected(true);
                       gender="Female";
                     }           
                  }
                              
                con.close();
	} 
        catch (Exception e)
        {
	   e.printStackTrace();
	}
    }
    
    private void insert(){
       java.util.Date utildt=DOBchooser.getDate();
       java.sql.Date birthDate = new java.sql.Date(utildt.getTime());
       setGender();
       
        try 
        {			
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
		PreparedStatement ps;
                ps=con.prepareStatement(REGISTER_SQL);
                	
                  ps.setString(1, tfirst.getText());
		  ps.setString(2, tlast.getText());
		  ps.setDate(3, birthDate);
		  ps.setString(4, gender);
                  ps.setString(5, taddress.getText());
                  ps.setString(6, temail.getText());
                  ps.setInt(7, Integer.parseInt(tmobile.getText()));
                  ps.setInt(8, Integer.parseInt(thome.getText()));
                  ps.setString(9, tparent.getText());
                  ps.setString(10, tnic.getText());
                  ps.setInt(11, Integer.parseInt(tcontact.getText()));
                  ps.executeUpdate();
                  
                  JOptionPane.showMessageDialog(null,"Record Added Successfully!", "", JOptionPane.WARNING_MESSAGE);           	
                  con.close();
                  
	} 
        
        catch (Exception e)
        {
	   JOptionPane.showMessageDialog(null,"Error! Enter valid data!", "", JOptionPane.ERROR_MESSAGE);
	}
    }
    
    
    private void update(){
       id = Integer.parseInt(regCombo.getSelectedItem().toString());
       java.util.Date utildt=DOBchooser.getDate();
       java.sql.Date birthDate = new java.sql.Date(utildt.getTime());     	
       setGender();
       
        try 
        {		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
		PreparedStatement ps;
                ps=con.prepareStatement(UPDATE_SQL);
                  ps.setString(1, tfirst.getText());
		  ps.setString(2, tlast.getText());
		  ps.setDate(3, birthDate);
		  ps.setString(4, gender);
                  ps.setString(5, taddress.getText());
                  ps.setString(6, temail.getText());
                  ps.setInt(7, Integer.parseInt(tmobile.getText()));
                  ps.setInt(8, Integer.parseInt(thome.getText()));
                  ps.setString(9, tparent.getText());
                  ps.setString(10, tnic.getText());
                  ps.setInt(11, Integer.parseInt(tcontact.getText()));
                  ps.setInt(12, id);
                  ps.executeUpdate();
                  
                  JOptionPane.showMessageDialog(null,"Record Updated Successfully!", "", JOptionPane.WARNING_MESSAGE);    
                con.close();
	} 
        catch (Exception e)
        {
           JOptionPane.showMessageDialog(null,"Error! Enter valid data!", "", JOptionPane.ERROR_MESSAGE);    
	   e.printStackTrace();
	}  
    }
    
    
    private void delete(){
       try 
        {		
                id = Integer.parseInt(regCombo.getSelectedItem().toString());
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
		PreparedStatement ps;
                ps=con.prepareStatement(DELETE_SQL);
                ps.setInt(1, id);                                
                ps.executeUpdate();               
                con.close();
                JOptionPane.showMessageDialog(null,"Record Deleted Successfully!", "", JOptionPane.WARNING_MESSAGE);                 
	} 
        catch (Exception e)
        {
	   e.printStackTrace();
	}   
    }
    
    
    private void clear(){
        regCombo.setSelectedItem(null);
        tfirst.setText("");
        tlast.setText("");
        DOBchooser.setCalendar(null);
        buttonGroup1.clearSelection();
        taddress.setText("");
        temail.setText("");
        tmobile.setText("");
        thome.setText("");
        tparent.setText("");
        tnic.setText("");
        tcontact.setText("");
    }
    
    
    private void logout(){
      login lg = new login();
      lg.setVisible(true);
      this.setVisible(false);
    }
    
    private void rbmaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbmaleActionPerformed

    }//GEN-LAST:event_rbmaleActionPerformed

    private void bregisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bregisterActionPerformed
      insert();
    }//GEN-LAST:event_bregisterActionPerformed

    private void rbfemaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbfemaleActionPerformed

    }//GEN-LAST:event_rbfemaleActionPerformed

    private void bclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bclearActionPerformed
       clear();
    }//GEN-LAST:event_bclearActionPerformed

    private void regComboPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_regComboPopupMenuWillBecomeVisible
       loadIndexes();     
    }//GEN-LAST:event_regComboPopupMenuWillBecomeVisible

    private void regComboFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_regComboFocusGained

    }//GEN-LAST:event_regComboFocusGained

    private void regComboPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_regComboPopupMenuWillBecomeInvisible

    }//GEN-LAST:event_regComboPopupMenuWillBecomeInvisible

    private void regComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regComboActionPerformed
      if(regCombo.getSelectedItem()!=null){
        loadData();
      }
    }//GEN-LAST:event_regComboActionPerformed

    private void blogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_blogoutActionPerformed
      logout();
    }//GEN-LAST:event_blogoutActionPerformed

    private void bupdtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bupdtActionPerformed
      update();
    }//GEN-LAST:event_bupdtActionPerformed

    private void bdeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bdeleteActionPerformed
      int res = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "file", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
       if(res == JOptionPane.YES_OPTION){
        delete();        
        clear();
        regCombo.removeItemAt(regCombo.getSelectedIndex());
       }      
       else if(res == JOptionPane.NO_OPTION){
        JOptionPane.showMessageDialog(null,"Operation Canceled!", "", JOptionPane.WARNING_MESSAGE); 
       }                   
    }//GEN-LAST:event_bdeleteActionPerformed

    private void rbmaleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbmaleMouseClicked
       gender="Male";
    }//GEN-LAST:event_rbmaleMouseClicked

    private void rbfemaleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbfemaleMouseClicked
       gender="Female";
    }//GEN-LAST:event_rbfemaleMouseClicked

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
      if(!account.equals("Admin") ){
        bedit.setVisible(false);
      }
    }//GEN-LAST:event_formComponentShown

    private void regComboMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regComboMouseClicked

    }//GEN-LAST:event_regComboMouseClicked

    private void tmobileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tmobileKeyPressed
       checkLength(tmobile);  	
    }//GEN-LAST:event_tmobileKeyPressed

    private void tmobileKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tmobileKeyTyped
        
    }//GEN-LAST:event_tmobileKeyTyped

    private void thomeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_thomeKeyPressed
       checkLength(thome);  
    }//GEN-LAST:event_thomeKeyPressed

    private void tcontactKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcontactKeyPressed
       checkLength(tcontact);  
    }//GEN-LAST:event_tcontactKeyPressed

    private void bclear1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bclear1ActionPerformed
       viewTable obj = new viewTable();
       obj.setVisible(true);
    }//GEN-LAST:event_bclear1ActionPerformed

    private void beditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beditActionPerformed
       editAdmin obj = new editAdmin();
       obj.setVisible(true);
    }//GEN-LAST:event_beditActionPerformed

    private void bchangepwActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bchangepwActionPerformed
        changepw obj = new changepw();
        obj.setVisible(true);
    }//GEN-LAST:event_bchangepwActionPerformed

    
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new register().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser DOBchooser;
    private javax.swing.JButton bchangepw;
    private javax.swing.JButton bclear;
    private javax.swing.JButton bclear1;
    private javax.swing.JButton bdelete;
    private javax.swing.JButton bedit;
    private javax.swing.JButton blogout;
    private javax.swing.JButton bregister;
    private javax.swing.JButton bupdt;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbfemale;
    private javax.swing.JRadioButton rbmale;
    private javax.swing.JComboBox<String> regCombo;
    private javax.swing.JTextArea taddress;
    private javax.swing.JTextField tcontact;
    private javax.swing.JTextField temail;
    private javax.swing.JTextField tfirst;
    private javax.swing.JTextField thome;
    private javax.swing.JTextField tlast;
    private javax.swing.JTextField tmobile;
    private javax.swing.JTextField tnic;
    private javax.swing.JTextField tparent;
    // End of variables declaration//GEN-END:variables
}
